-- Generated with Durty Cloth Tool v3.1.0.3 (https://gta.clothing)

fx_version 'cerulean'
game { 'gta5' }

author 'Jaelix'
files {
  'mp_m_freemode_01_mp_m_lotus_designs_flag_shop.meta',
  'mp_f_freemode_01_mp_f_lotus_designs_shop.meta'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_m_freemode_01_mp_m_lotus_designs_flag_shop.meta'
data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_f_freemode_01_mp_f_lotus_designs_flag_shop.meta'