Thanks for buying my pack

To Install this pack follow the instructions below:

1. Drag the entire `LOTUS_DESIGNS` folder into your server’s `resources` directory.
2. Add this line to your `server.cfg`:
ensure LOTUS_DESIGNS_GANG_PACKAGE

That’s it, plug and play.

👉 Join the Discord https://discord.gg/u5xgEmpEMz to request something custom or view more drops.

https://discord.gg/u5xgEmpEMz 
https://discord.gg/u5xgEmpEMz
https://discord.gg/u5xgEmpEMz

██████╗░██╗░██████╗░█████╗░░█████╗░██████╗░██████╗░
██╔══██╗██║██╔════╝██╔══██╗██╔══██╗██╔══██╗██╔══██╗
██║░░██║██║╚█████╗░██║░░╚═╝██║░░██║██████╔╝██║░░██║
██║░░██║██║░╚═══██╗██║░░██╗██║░░██║██╔══██╗██║░░██║
██████╔╝██║██████╔╝╚█████╔╝╚█████╔╝██║░░██║██████╔╝
╚═════╝░╚═╝╚═════╝░░╚════╝░░╚════╝░╚═╝░░╚═╝╚═════╝░